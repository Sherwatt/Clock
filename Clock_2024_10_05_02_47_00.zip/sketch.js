function setup() {
  createCanvas(500, 500);
  angleMode(DEGREES);
}

function draw() {
  background(0);
  translate(250, 250);
  rotate(-90);
  
  let radius = min(width, height) / 2;
  hour_radius = radius * 0.74;
  
  let sec=second();
  let mn=minute();
  let hrs=hour();
  
  noFill();
  strokeWeight(8);
  stroke(255);
  
  push();
  stroke(sec * 4.1, 75, 135);
  let end1 = map(sec, 0, 60, 0, 360);
  arc(0, 0, 450, 450, 0, end1);  //second hand
  pop();
  
  push();
  stroke(135, mn* 4.1, 75);
  let end2 = map(mn, 0, 60, 0, 360);
  arc(0, 0, 420, 420, 0, end2);  //minute hand
  pop();
  
  push();
  stroke(75, 135, hrs * 10);
  let end3 = map(hrs % 12, 0, 12, 0, 360);
  arc(0, 0, 390, 390, 0, end3);  //hour hand
  pop();
  
  push();
  for (let marks = 0; marks < 12; marks += 1) {
    point(0, -hour_radius);
    rotate(30);
  }
  pop();
}